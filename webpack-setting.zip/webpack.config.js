const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const path = require('path');

module.exports = {
	entry: './src/js/app.js',
	output: {
		path: path.join(__dirname, '/dist'),
		filename: 'app.bundle.js'
	},
	module: {
		rules: [
			{
				test: /\.scss$/,
				use: [
					{
						loader: MiniCssExtractPlugin.loader,
						options: {
							publicPath: 'dist',
							hmr: process.env.NODE_ENV === 'development',
						},
					},
					'css-loader',
					'sass-loader'
				],
			}
		]
	},
	devServer: {
		contentBase: path.join(__dirname, '/dist'),
		compress: true,
		port: 9000
	},
	plugins: [
		new HtmlWebpackPlugin({
			title: 'Hello Webpack Project!',
			/*
			minify: {
				collapseWhitespace: false // 문서의 텍스트 노드에서 공백을 제거
			},
			hash: true, // CSS 혹은 JS 파일에 고유한 웹팩 컴파일 해시를 추가
			*/
			template: './src/index.ejs'
		}),
		new MiniCssExtractPlugin({
			filename: 'app.css',
			chunkFilename: 'kcm.css', // ????
		}),
	]
};
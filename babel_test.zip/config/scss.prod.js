var sass = require('node-sass');
var glob = require('node-sass-globbing');

sass.render({
	file: './sass'
})

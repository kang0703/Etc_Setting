let kcm = document.querySelector(".kcm");
let tamp = `
	<table>
		<thead>
			<tr>
				<th>head</th>
				<th>head</th>
				<th>head</th>
				<th>head</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>123</td>
				<td>123</td>
				<td>123</td>
				<td>123</td>
			</tr>
		</tbody>
	</table>
`;

kcm.innerHTML = tamp;

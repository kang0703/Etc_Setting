import style from "./main.css";

console.log(`index js1111111111 입니다.`);
const arr = [1, 2, 3, 4];
const iAmJavascriptES6 = () => console.log(...arr);
window.iAmJavascriptES6 = iAmJavascriptES6;